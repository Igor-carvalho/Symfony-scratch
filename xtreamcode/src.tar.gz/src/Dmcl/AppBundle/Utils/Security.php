<?php
/**
 * Created by PhpStorm.
 * User: yordan
 * Date: 12/13/16
 * Time: 3:59 AM
 */

namespace Dmcl\AppBundle\Utils;


class Security
{
    public static function hash() {

    }
}