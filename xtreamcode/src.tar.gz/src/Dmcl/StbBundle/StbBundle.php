<?php

namespace Dmcl\StbBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class StbBundle extends Bundle
{
}
